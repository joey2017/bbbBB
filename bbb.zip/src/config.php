<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/8
 * Time: 14:10
 */

return [
    'dsn'      => "mysql:host=111.230.221.134;dbname=wx;charset=utf8",
    'username' => "wx",
    'password' => "JKzfSHsZw2DYD5Jk"
];